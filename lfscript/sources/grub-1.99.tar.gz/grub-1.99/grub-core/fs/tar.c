#define MODE_USTAR 1
#include "cpio.c"
