#define MODE_BIGENDIAN 1
#include "afs.c"
